# Build Apps with Vue 3 & Firebase
All course files for the Vue 3 &amp; Firebase Udemy course.

## How to use these files
Each lesson has it's own branch in this repo. To see the code for a particular lesson, select that lesson from the branch drop-dow in the top-left of the screen. Then you can download the files by clicking on the green 'Code' button & selecting 'Download Zip'.